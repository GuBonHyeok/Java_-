package days01;

/**
 * @author Bon
 * @date 2023. 12. 29. - 오후 4:49:08
 * @subject
 * @content
 */
public class Ex05 {

	public static void main(String[] args) {
		// 

	} // main

} //class
