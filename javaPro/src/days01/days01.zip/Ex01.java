package days01;  //패키지 마지막에 새미콜론 넣는 것 기억

// Alt + Shift + j


/**
 * @author Bon
 * @date 2023. 12. 29. - 오후 2:32:56
 * @subject 수업 1일차 첫 번째 예제
 * @content JDK 11 설치 및 확인
 * 					자바 프로그램의 기본 구조 설명
 * 					자바 클래스 선언 형식 설명
 * 					자바 함수(메서드) 선언 형식
 */
public class Ex01{
	public static void main(String [] args) {  //프로그램 시작		
	
		// 주석(comment)
		// 프로그램 실행에서는 상관없이 설명을 하기 위한 것
        /* 
         
          여러 라인 주석처리
          
         */		
		
	} //프로그램 종료
	
	

}
