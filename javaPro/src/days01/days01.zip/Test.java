package days01;

public class Test {
	  public static void main(String[] args) {
	      String name = "구본혁";
	      int age = 29;
	  
	      System.out.println("이름 : \"" + name
	  				+ "\", 나이 : " + age + " 살 입니다." );

	  }
	}