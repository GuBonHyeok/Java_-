package days01;

public class Ex04_02 {
	public static void main(String[] args) {
		
		// 여기서 + : 산술 연산자(덧셈) 
		System.out.println(3 + 5);   // 8
		// 여기서 + : 문자열 연결 연산자
		System.out.println("3" + 5);   // 35
		System.out.println("3" + 5);   // 문자열 "3"과 정수 5가 문자열 "5"가 되어 "35"
	}

}
