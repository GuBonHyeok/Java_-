package days14;

/**
 * @author Bonggu
 * @date 2024. 1. 18.
 * @subject 좌표를 다루는 클래스 선언
 * @content
 */
public class Ex07_02 {

	public static void main(String[] args) {
		// 좌표를 다루는 클래스 선언해서 처리하면 용이하다 : Point 클래스
		Point p1 = new Point();
		p1.x = 1; p1.y =2;
		Point p2 = new Point();
		p2.x = 1; p2.y =2;
		Point p3 = new Point();
		p3.x = 1; p3.y =2;
		Point p4 = new Point();
		p4.x = 1; p4.y =2;
		Point p5 = new Point();
		p5.x = 1; p5.y =2;
		
		p1.dispXY();
		p2.dispXY();
		p3.dispXY();
		p4.dispXY();
		p5.dispXY();


	} // main

} // class

