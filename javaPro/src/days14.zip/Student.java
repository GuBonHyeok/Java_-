package days14;
/**
 * @author Bonggu
 * @date 2024. 1. 18.
 * @subject 학생 정보 (이름, 점수) 저장하는 클래스
 * @content
 */
class Student {

	//field
	String name;
	int kor, eng, mat, tot;
	double avg;
	int rank;

	// method
	public void disInfo() {
		System.out.printf("%s\t%s\t%s\t%s\t%s\t%.2f\t%d등\n"
				, name
				, kor
				, eng
				, mat
				, tot
				, avg
				, rank);
	
	} //disInfo

} //Student
