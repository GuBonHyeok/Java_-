package days14;

import java.util.Random;
import java.util.Scanner;

/**
 * @author Bonggu
 * @date 2024. 1. 18.
 * @subject 인스턴스화
 * @content
 */
public class Ex03_02 {

	public static void main(String[] args) {
		//System은 인스턴스화, 즉 객체 생성을 할 수 없는 클래스다. 
		Scanner scanner = new Scanner(System.in); //scanner 객체 생성
		Random rnd = new Random(); //rnd 객체 생성

		//[문제] 스캐너 객체를 생성만 하는 코딩을 하세요.
		//					인스턴스화 하는 코딩만 하세요.
		// new Scanner(System.in);
	}//main

}//class
