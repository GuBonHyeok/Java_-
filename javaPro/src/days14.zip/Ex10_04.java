package days14;

/**
 * @author Bonggu
 * @date 2024. 1. 18.
 * @subject
 * @content
 */
public class Ex10_04 {

	public static void main(String[] args) {
		//체이닝 : 함수를 연달아 쓰는 것 p.A().B(); 이면 p.A() 함수의 리턴값을 가지고 .B()를 실행한다.

	} //main

} //class
