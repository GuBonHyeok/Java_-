package days14;

public class Time {

	 public int hour;
	   int minute;
	   protected int second;
	   private int millisecond;

	}
