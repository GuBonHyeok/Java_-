package days16;

/**
 * @author Bonggu
 * @date 2024. 1. 22.- 오후 12:18:28
 * @subject
 * @content
 */
public class Ex06 {

	public static void main(String[] args) {
		// 단일 상속 (Single Inheritance)
		// 다중 상속 (Multiple Inheritance)
		// 자바는 다중상속을 지원하지 않는다.
		

	} //main

} //class

/*
class Tv{ }
class VCR { }

// Tv + VCR
class TVCR extends Tv, VCR{ //여러개 클래스로부터 상속받는 다중상속 X. 자바에서는 다중상속 지원 X
	
}

class TVCR extends Tv{ 	 //Tv한테서는 상속받고			(is - a)
   VCR vcr = new VCR();	//VCR은 포함시키면 구현 가능 (has - a)
}

>>>>>> 자바에서는 인터페이스를 사용해서 다중 상속을 구현할 수 있다. <<<<<<<<<<

*/


