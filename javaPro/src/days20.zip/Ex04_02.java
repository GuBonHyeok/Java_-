package days20;

import java.util.Calendar;
import java.util.Date;

/**
 * @author Bonggu
 * @date 2024. 1. 26.- 오전 11:43:39
 * @subject Calendar -> Date 객체로 변환, Date -> Calendar 객체로 변환할 줄 알아야하함
 * @content
 */
public class Ex04_02 {

	public static void main(String[] args) {
		// Calendar -> Date 객체로 변환 >> Cal
		Calendar c = Calendar.getInstance();
		Date date = c.getTime();

		// Date -> Calendar 객체로 변환할 줄 알아야하함

	}

}
