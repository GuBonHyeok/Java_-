package days15;

/**
 * @author Bonggu
 * @date 2024. 1. 19.- 오전 10:52:43
 * @subject 
 * @content
 */
public class Ex02 {

	public static void main(String[] args) {


	} //main

} //class
