package days15;

/**
 * @author Bonggu
 * @date 2024. 1. 19.- 오후 3:44:12
 * @subject
 * @content
 */
public class Ex08 {

	public static void main(String[] args) {
//		System.out; > 여기 있는 모든 메서드 스테틱
//		System.in; > 여기 있는 모든 메서드 스테틱
		
//		Math. > 스태틱
		
		
		

	} //main

} //class
