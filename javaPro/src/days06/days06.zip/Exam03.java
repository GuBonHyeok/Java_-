package days06;

public class Exam03 {
	public static void main(String[] args) {
		String name[] = {"구","본","혁"};		
		char nameArr[] = {' ', ' ', ' '};
		for (int i = 0; i < name.length; i++ ) {
			
			nameArr = name.charAt();				
			System.out.print(name);	// m 배열을 출력하는 코딩
		}
		
		//		for (자료형 변수명 : 배열 또는 컬렉션) { 배열 또는 컬렉션에 반복적으로 사용하는 반복문
		//	
		//							}
		
//		for ( nameArr[] : name[]) { //m배열의 값을 하나씩 꺼내 n에 대입하는 작업
	//		System.out.println(n);
					
		}


	}


