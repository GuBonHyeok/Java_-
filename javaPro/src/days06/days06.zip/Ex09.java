package days06;

/**
 * @author BongGu
 * @date 2024. 1. 8. - 오후 5:37:32
 * @subject 별 (*) 이용해서 각종 모양 찍기
 * @content
 */
public class Ex09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
