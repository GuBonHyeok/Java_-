package days06;

public class Ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}