package days10;

public class Ex05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	} //main

} //class