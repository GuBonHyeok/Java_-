package days10;

import java.util.Scanner;

/**
 * @author BongGu
 * @date 2024. 1. 11. - 오후 5:28:56
 * @subject
 * @content
 */
public class Ex01_02 {

	public static void main(String[] args) {

		int n = 125;

		int remainder=0, share=0;

		String strHex = "";
		while ( n != 0 ) {
			share = n / 16;
			remainder = n % 16;
			String strResult= "";

			switch (remainder) {
			case 10: remainder = 'A'; break;
			case 11: remainder = 'B'; break;
			case 12: remainder = 'C'; break;
			case 13: remainder = 'D'; break;
			case 14: remainder = 'E'; break;
			case 15: remainder = 'F'; break;
			default: remainder = remainder + '0'; break;
			}
			strHex+= "["+(char)remainder+"]";
			n = share;
		} //while


		System.out.print( strHex);

		String reverseStrResult = "";
		for (int i = 0; i < strHex.length(); i++) {
			reverseStrResult += strHex.charAt(strHex.length()-1-i);
		}

	}//main


} //class

