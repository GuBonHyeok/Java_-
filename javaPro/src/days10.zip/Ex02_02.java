package days10;

/**
 * @author BongGu
 * @date 2024. 1. 12. - 오후 12:26:08
 * @subject 마지막 날짜 구하기 (소개 예제)
 * @content
 */
public class Ex02_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
