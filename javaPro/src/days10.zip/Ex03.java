package days10;

/**
 * @author BongGu
 * @date 2024. 1. 12. - 오후 2:30:39
 * @subject 배열에 관하여
 * @content
 */
public class Ex03 {

	public static void main(String[] args) {
		/*
		 * [배열] + 제어문(for문)과 같이 쓰임
		 * 1. 자료형
		 *		1) 기본형 - 8가지
		 *		2) 참조형 - [배열], 클래스, 인터페이스
		 * 2. 배열의 정의
		 *		1) 같은 자료형의 메모리 상에 연속적으로 놓이게 하는 것
		 * 3. 
		 * 
		 * 
		 * 
		 * */
		
		


	} //main

} //class
