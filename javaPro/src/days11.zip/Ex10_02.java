package days11;

import java.util.Arrays;

/**
 * @author BongGu
 * @date 2024. 1. 15. - 오후 5:12:08
 * @subject
 * @content
 */
public class Ex10_02 {

	public static void main(String[] args) {
		int [] m = {3,5,2,4,1};
		System.out.println(Arrays.toString(m));
		
		Arrays.sort(m); //Arrays.sort에 정렬하는 함수가 있다. 하지만 로직은 알아둬야한다.
		
		System.out.println(Arrays.toString(m));


	}//main

}//class
