package days12;

import java.util.Arrays;

public class Exam {

	public static void main(String[] args) {
		int n = 5;
		int [][] lotto = new int[n][6];
		for (int i = 0; i < lotto.length; i++) {
			for (int j = 0; j < lotto[i].length; j++) {
				System.out.printf("lotto%02d=[%02d] ", i, lotto[i][j]);
				if (j % 6 ==5) {
					System.out.println();				
				}				
			}//for j
		}//for i
	}//main

}//class
