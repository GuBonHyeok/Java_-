package days12;

/**
 * @author BongGu
 * @date 2024. 1. 16. - 오후 2:35:05
 * @subject git 사용법
 * @content
 */
public class Ex08 {

	public static void main(String[] args) {

	}

}
