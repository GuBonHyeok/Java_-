package days12;

/**
 * @author BongGu
 * @date 2024. 1. 16. - 오전 10:22:38
 * @subject 다차원 배열
 * @content
 */
public class Ex02 {

	public static void main(String[] args) {
		// 배열은 초기화하지 않아도 해당 자료형의 기본값으로 초기화되어 있다.
		//다차원 배열 - 배열의 배열. 2차원 배열 : 1차원 배열의 배열, 3차원 배열 : 2차원 배열의 배열

		int [] m = new int [3];
		m[0] = 1;
		m[1] = 2;
		m[2] = 3;
		
		//배열 초기화
		int [] m1 = new int [] {1,2,3};
		int [] m2 = {1,2,3};
		
		
		
		
	} //main

}
