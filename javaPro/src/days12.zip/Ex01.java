package days12;

/**
 * @author BongGu
 * @date 2024. 1. 16. - 오전 10:15:00
 * @subject
 * @content
 */
public class Ex01 {

	public static void main(String[] args) {
		
		// main() 의 매개변수 String[] args 의 의미?
		for (int i = 0; i < args.length; i++) {
			System.out.printf("[%d] - %s\n",i,args[i]);			
		} //for
		System.out.println("end");
		

	} //main

} //class
